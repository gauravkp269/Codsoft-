import cv2
import numpy as np
from PIL import ImageFont, ImageDraw, Image

def generate_handwritten_image(text, font_path="AlexBrush-Regular.ttf", output_file="output.png", font_size=48):
    # Create blank white canvas
    width, height = 800, 200
    image = np.ones((height, width, 3), dtype=np.uint8) * 255

    # Convert to PIL image
    pil_img = Image.fromarray(image)
    draw = ImageDraw.Draw(pil_img)

    # Load handwriting-like font
    try:
        font = ImageFont.truetype(font_path, font_size)
    except IOError:
        print("Font file not found. Make sure AlexBrush-Regular.ttf is in the same directory.")
        return

    # Draw text
    draw.text((50, 60), text, font=font, fill=(0, 0, 0))

    # Convert back to OpenCV format and save
    final_image = np.array(pil_img)
    cv2.imwrite(output_file, final_image)
    print(f"Image saved as: {output_file}")

# Example usage
if __name__ == "__main__":
    your_text = "Hello Gaurav, welcome to handwritten text generation!"
    generate_handwritten_image(your_text)
