# Handwritten Text Generator 🖋️

This project generates realistic handwritten-style images from input text using Python and a handwriting-like font.

## Features
- Simple and easy to use
- Generates PNG image that looks like handwritten notes
- Perfect for ML/AI demo projects

## How to Use

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Download the handwriting font [Alex Brush](https://fonts.google.com/specimen/Alex+Brush)
   and place `AlexBrush-Regular.ttf` in this directory.

3. Run the script:
   ```
   python handwritten_text.py
   ```

4. Output image `output.png` will be saved in the folder.

## Credits
- Font: [Alex Brush](https://fonts.google.com/specimen/Alex+Brush)
