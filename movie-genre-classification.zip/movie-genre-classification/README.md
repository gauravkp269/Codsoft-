# Movie Genre Classification 🎬📚

This project uses machine learning to classify movie plots into genres based on their descriptions.

## Features
- Text classification using `TfidfVectorizer` and logistic regression
- Uses a dataset of movie plots and genres
- Easy to extend with real-world datasets

## How to Use

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Add your dataset `movie_data.csv` with two columns:
   - `Plot`: The movie description or summary
   - `Genre`: The actual genre (e.g., Action, Comedy, Drama)

3. Run the script:
   ```
   python movie_genre_classifier.py
   ```

4. The script will print the model accuracy.

## Note
You can improve performance by:
- Using more data
- Trying other models (SVM, Naive Bayes)
- Using deep learning (like LSTM or BERT)

## License
This project is for educational/demo purposes.
