# Customer Churn Prediction 🔍📉

This project predicts whether a customer is likely to churn using logistic regression.

## Features
- Uses `scikit-learn` and `pandas`
- Logistic regression model
- Based on a sample dataset (`churn_data.csv`)

## How to Use

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Add your dataset `churn_data.csv` with columns:
   - Features (numerical or one-hot encoded)
   - Target column: `Churn` (0 or 1)

3. Run the script:
   ```
   python churn_predictor.py
   ```

4. View the output accuracy of the churn prediction model.

## Note
- You can use real or dummy churn data.
- The model can be improved by preprocessing and feature engineering.

## License
This project is for educational purposes.
